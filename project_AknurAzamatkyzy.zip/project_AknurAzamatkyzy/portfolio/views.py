from django.shortcuts import render

def home(request):
    return render(request, 'portfolio/home.html')


def destinations(request):
    return render(request, 'portfolio/destinations.html')

def portfolio(request):
    return render(request, 'portfolio/portfolio.html')

